patient credentials ={
username : 8888
password: "Akshay@pal"
}

allPhysiodata credentials=[
physioOneData = {
id: 5890
password: "Doctor@raj"
};
physioTwoData = {
id: 5891,
password: "Neha@Doc"
};
physioThreeData = {
id: 5892,
password: "Reddykrishna"
};
]

salesTeam credentials = {
id: 5623
password: "Sales@123"
};
